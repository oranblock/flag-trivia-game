# app.py
from flask import Flask, render_template, request, session, redirect, url_for, jsonify, send_from_directory
import random
import requests
import os
import time
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key'
FLAG_API = 'https://flagpedia.net/data/flags/normal/{}.png'
FLAGS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'flags')

# Complete world country data (ISO codes)
# This is a comprehensive list of countries with their ISO codes and Arabic names
COUNTRIES = {
    'Afghanistan': {'code': 'af', 'arabic': 'أفغانستان'},
    'Albania': {'code': 'al', 'arabic': 'ألبانيا'},
    'Algeria': {'code': 'dz', 'arabic': 'الجزائر'},
    'Andorra': {'code': 'ad', 'arabic': 'أندورا'},
    'Angola': {'code': 'ao', 'arabic': 'أنغولا'},
    'Antigua and Barbuda': {'code': 'ag', 'arabic': 'أنتيغوا وبربودا'},
    'Argentina': {'code': 'ar', 'arabic': 'الأرجنتين'},
    'Armenia': {'code': 'am', 'arabic': 'أرمينيا'},
    'Australia': {'code': 'au', 'arabic': 'أستراليا'},
    'Austria': {'code': 'at', 'arabic': 'النمسا'},
    'Azerbaijan': {'code': 'az', 'arabic': 'أذربيجان'},
    'Bahamas': {'code': 'bs', 'arabic': 'جزر البهاما'},
    'Bahrain': {'code': 'bh', 'arabic': 'البحرين'},
    'Bangladesh': {'code': 'bd', 'arabic': 'بنغلاديش'},
    'Barbados': {'code': 'bb', 'arabic': 'بربادوس'},
    'Belarus': {'code': 'by', 'arabic': 'بيلاروسيا'},
    'Belgium': {'code': 'be', 'arabic': 'بلجيكا'},
    'Belize': {'code': 'bz', 'arabic': 'بليز'},
    'Benin': {'code': 'bj', 'arabic': 'بنين'},
    'Bhutan': {'code': 'bt', 'arabic': 'بوتان'},
    'Bolivia': {'code': 'bo', 'arabic': 'بوليفيا'},
    'Bosnia and Herzegovina': {'code': 'ba', 'arabic': 'البوسنة والهرسك'},
    'Botswana': {'code': 'bw', 'arabic': 'بوتسوانا'},
    'Brazil': {'code': 'br', 'arabic': 'البرازيل'},
    'Brunei': {'code': 'bn', 'arabic': 'بروناي'},
    'Bulgaria': {'code': 'bg', 'arabic': 'بلغاريا'},
    'Burkina Faso': {'code': 'bf', 'arabic': 'بوركينا فاسو'},
    'Burundi': {'code': 'bi', 'arabic': 'بوروندي'},
    'Cambodia': {'code': 'kh', 'arabic': 'كمبوديا'},
    'Cameroon': {'code': 'cm', 'arabic': 'الكاميرون'},
    'Canada': {'code': 'ca', 'arabic': 'كندا'},
    'Cape Verde': {'code': 'cv', 'arabic': 'الرأس الأخضر'},
    'Central African Republic': {'code': 'cf', 'arabic': 'جمهورية أفريقيا الوسطى'},
    'Chad': {'code': 'td', 'arabic': 'تشاد'},
    'Chile': {'code': 'cl', 'arabic': 'تشيلي'},
    'China': {'code': 'cn', 'arabic': 'الصين'},
    'Colombia': {'code': 'co', 'arabic': 'كولومبيا'},
    'Comoros': {'code': 'km', 'arabic': 'جزر القمر'},
    'Congo': {'code': 'cg', 'arabic': 'الكونغو'},
    'Costa Rica': {'code': 'cr', 'arabic': 'كوستاريكا'},
    'Croatia': {'code': 'hr', 'arabic': 'كرواتيا'},
    'Cuba': {'code': 'cu', 'arabic': 'كوبا'},
    'Cyprus': {'code': 'cy', 'arabic': 'قبرص'},
    'Czech Republic': {'code': 'cz', 'arabic': 'جمهورية التشيك'},
    'Denmark': {'code': 'dk', 'arabic': 'الدنمارك'},
    'Djibouti': {'code': 'dj', 'arabic': 'جيبوتي'},
    'Dominica': {'code': 'dm', 'arabic': 'دومينيكا'},
    'Dominican Republic': {'code': 'do', 'arabic': 'جمهورية الدومينيكان'},
    'Ecuador': {'code': 'ec', 'arabic': 'الإكوادور'},
    'Egypt': {'code': 'eg', 'arabic': 'مصر'},
    'El Salvador': {'code': 'sv', 'arabic': 'السلفادور'},
    'Equatorial Guinea': {'code': 'gq', 'arabic': 'غينيا الاستوائية'},
    'Eritrea': {'code': 'er', 'arabic': 'إريتريا'},
    'Estonia': {'code': 'ee', 'arabic': 'إستونيا'},
    'Eswatini': {'code': 'sz', 'arabic': 'إسواتيني'},
    'Ethiopia': {'code': 'et', 'arabic': 'إثيوبيا'},
    'Fiji': {'code': 'fj', 'arabic': 'فيجي'},
    'Finland': {'code': 'fi', 'arabic': 'فنلندا'},
    'France': {'code': 'fr', 'arabic': 'فرنسا'},
    'Gabon': {'code': 'ga', 'arabic': 'الغابون'},
    'Gambia': {'code': 'gm', 'arabic': 'غامبيا'},
    'Georgia': {'code': 'ge', 'arabic': 'جورجيا'},
    'Germany': {'code': 'de', 'arabic': 'ألمانيا'},
    'Ghana': {'code': 'gh', 'arabic': 'غانا'},
    'Greece': {'code': 'gr', 'arabic': 'اليونان'},
    'Grenada': {'code': 'gd', 'arabic': 'غرينادا'},
    'Guatemala': {'code': 'gt', 'arabic': 'غواتيمالا'},
    'Guinea': {'code': 'gn', 'arabic': 'غينيا'},
    'Guinea-Bissau': {'code': 'gw', 'arabic': 'غينيا بيساو'},
    'Guyana': {'code': 'gy', 'arabic': 'غيانا'},
    'Haiti': {'code': 'ht', 'arabic': 'هايتي'},
    'Honduras': {'code': 'hn', 'arabic': 'هندوراس'},
    'Hungary': {'code': 'hu', 'arabic': 'المجر'},
    'Iceland': {'code': 'is', 'arabic': 'آيسلندا'},
    'India': {'code': 'in', 'arabic': 'الهند'},
    'Indonesia': {'code': 'id', 'arabic': 'إندونيسيا'},
    'Iran': {'code': 'ir', 'arabic': 'إيران'},
    'Iraq': {'code': 'iq', 'arabic': 'العراق'},
    'Ireland': {'code': 'ie', 'arabic': 'أيرلندا'},
    'Israel': {'code': 'il', 'arabic': 'إسرائيل'},
    'Italy': {'code': 'it', 'arabic': 'إيطاليا'},
    'Jamaica': {'code': 'jm', 'arabic': 'جامايكا'},
    'Japan': {'code': 'jp', 'arabic': 'اليابان'},
    'Jordan': {'code': 'jo', 'arabic': 'الأردن'},
    'Kazakhstan': {'code': 'kz', 'arabic': 'كازاخستان'},
    'Kenya': {'code': 'ke', 'arabic': 'كينيا'},
    'Kiribati': {'code': 'ki', 'arabic': 'كيريباتي'},
    'Kuwait': {'code': 'kw', 'arabic': 'الكويت'},
    'Kyrgyzstan': {'code': 'kg', 'arabic': 'قيرغيزستان'},
    'Laos': {'code': 'la', 'arabic': 'لاوس'},
    'Latvia': {'code': 'lv', 'arabic': 'لاتفيا'},
    'Lebanon': {'code': 'lb', 'arabic': 'لبنان'},
    'Lesotho': {'code': 'ls', 'arabic': 'ليسوتو'},
    'Liberia': {'code': 'lr', 'arabic': 'ليبيريا'},
    'Libya': {'code': 'ly', 'arabic': 'ليبيا'},
    'Liechtenstein': {'code': 'li', 'arabic': 'ليختنشتاين'},
    'Lithuania': {'code': 'lt', 'arabic': 'ليتوانيا'},
    'Luxembourg': {'code': 'lu', 'arabic': 'لوكسمبورغ'},
    'Madagascar': {'code': 'mg', 'arabic': 'مدغشقر'},
    'Malawi': {'code': 'mw', 'arabic': 'ملاوي'},
    'Malaysia': {'code': 'my', 'arabic': 'ماليزيا'},
    'Maldives': {'code': 'mv', 'arabic': 'جزر المالديف'},
    'Mali': {'code': 'ml', 'arabic': 'مالي'},
    'Malta': {'code': 'mt', 'arabic': 'مالطا'},
    'Marshall Islands': {'code': 'mh', 'arabic': 'جزر مارشال'},
    'Mauritania': {'code': 'mr', 'arabic': 'موريتانيا'},
    'Mauritius': {'code': 'mu', 'arabic': 'موريشيوس'},
    'Mexico': {'code': 'mx', 'arabic': 'المكسيك'},
    'Micronesia': {'code': 'fm', 'arabic': 'ميكرونيزيا'},
    'Moldova': {'code': 'md', 'arabic': 'مولدوفا'},
    'Monaco': {'code': 'mc', 'arabic': 'موناكو'},
    'Mongolia': {'code': 'mn', 'arabic': 'منغوليا'},
    'Montenegro': {'code': 'me', 'arabic': 'الجبل الأسود'},
    'Morocco': {'code': 'ma', 'arabic': 'المغرب'},
    'Mozambique': {'code': 'mz', 'arabic': 'موزمبيق'},
    'Myanmar': {'code': 'mm', 'arabic': 'ميانمار'},
    'Namibia': {'code': 'na', 'arabic': 'ناميبيا'},
    'Nauru': {'code': 'nr', 'arabic': 'ناورو'},
    'Nepal': {'code': 'np', 'arabic': 'نيبال'},
    'Netherlands': {'code': 'nl', 'arabic': 'هولندا'},
    'New Zealand': {'code': 'nz', 'arabic': 'نيوزيلندا'},
    'Nicaragua': {'code': 'ni', 'arabic': 'نيكاراغوا'},
    'Niger': {'code': 'ne', 'arabic': 'النيجر'},
    'Nigeria': {'code': 'ng', 'arabic': 'نيجيريا'},
    'North Korea': {'code': 'kp', 'arabic': 'كوريا الشمالية'},
    'North Macedonia': {'code': 'mk', 'arabic': 'مقدونيا الشمالية'},
    'Norway': {'code': 'no', 'arabic': 'النرويج'},
    'Oman': {'code': 'om', 'arabic': 'عمان'},
    'Pakistan': {'code': 'pk', 'arabic': 'باكستان'},
    'Palau': {'code': 'pw', 'arabic': 'بالاو'},
    'Palestine': {'code': 'ps', 'arabic': 'فلسطين'},
    'Panama': {'code': 'pa', 'arabic': 'بنما'},
    'Papua New Guinea': {'code': 'pg', 'arabic': 'بابوا غينيا الجديدة'},
    'Paraguay': {'code': 'py', 'arabic': 'باراغواي'},
    'Peru': {'code': 'pe', 'arabic': 'بيرو'},
    'Philippines': {'code': 'ph', 'arabic': 'الفلبين'},
    'Poland': {'code': 'pl', 'arabic': 'بولندا'},
    'Portugal': {'code': 'pt', 'arabic': 'البرتغال'},
    'Qatar': {'code': 'qa', 'arabic': 'قطر'},
    'Romania': {'code': 'ro', 'arabic': 'رومانيا'},
    'Russia': {'code': 'ru', 'arabic': 'روسيا'},
    'Rwanda': {'code': 'rw', 'arabic': 'رواندا'},
    'Saint Kitts and Nevis': {'code': 'kn', 'arabic': 'سانت كيتس ونيفيس'},
    'Saint Lucia': {'code': 'lc', 'arabic': 'سانت لوسيا'},
    'Saint Vincent and the Grenadines': {'code': 'vc', 'arabic': 'سانت فنسنت والغرينادين'},
    'Samoa': {'code': 'ws', 'arabic': 'ساموا'},
    'San Marino': {'code': 'sm', 'arabic': 'سان مارينو'},
    'Sao Tome and Principe': {'code': 'st', 'arabic': 'ساو تومي وبرينسيبي'},
    'Saudi Arabia': {'code': 'sa', 'arabic': 'المملكة العربية السعودية'},
    'Senegal': {'code': 'sn', 'arabic': 'السنغال'},
    'Serbia': {'code': 'rs', 'arabic': 'صربيا'},
    'Seychelles': {'code': 'sc', 'arabic': 'سيشل'},
    'Sierra Leone': {'code': 'sl', 'arabic': 'سيراليون'},
    'Singapore': {'code': 'sg', 'arabic': 'سنغافورة'},
    'Slovakia': {'code': 'sk', 'arabic': 'سلوفاكيا'},
    'Slovenia': {'code': 'si', 'arabic': 'سلوفينيا'},
    'Solomon Islands': {'code': 'sb', 'arabic': 'جزر سليمان'},
    'Somalia': {'code': 'so', 'arabic': 'الصومال'},
    'South Africa': {'code': 'za', 'arabic': 'جنوب أفريقيا'},
    'South Korea': {'code': 'kr', 'arabic': 'كوريا الجنوبية'},
    'South Sudan': {'code': 'ss', 'arabic': 'جنوب السودان'},
    'Spain': {'code': 'es', 'arabic': 'إسبانيا'},
    'Sri Lanka': {'code': 'lk', 'arabic': 'سريلانكا'},
    'Sudan': {'code': 'sd', 'arabic': 'السودان'},
    'Suriname': {'code': 'sr', 'arabic': 'سورينام'},
    'Sweden': {'code': 'se', 'arabic': 'السويد'},
    'Switzerland': {'code': 'ch', 'arabic': 'سويسرا'},
    'Syria': {'code': 'sy', 'arabic': 'سوريا'},
    'Taiwan': {'code': 'tw', 'arabic': 'تايوان'},
    'Tajikistan': {'code': 'tj', 'arabic': 'طاجيكستان'},
    'Tanzania': {'code': 'tz', 'arabic': 'تنزانيا'},
    'Thailand': {'code': 'th', 'arabic': 'تايلاند'},
    'Timor-Leste': {'code': 'tl', 'arabic': 'تيمور الشرقية'},
    'Togo': {'code': 'tg', 'arabic': 'توغو'},
    'Tonga': {'code': 'to', 'arabic': 'تونغا'},
    'Trinidad and Tobago': {'code': 'tt', 'arabic': 'ترينيداد وتوباغو'},
    'Tunisia': {'code': 'tn', 'arabic': 'تونس'},
    'Turkey': {'code': 'tr', 'arabic': 'تركيا'},
    'Turkmenistan': {'code': 'tm', 'arabic': 'تركمانستان'},
    'Tuvalu': {'code': 'tv', 'arabic': 'توفالو'},
    'Uganda': {'code': 'ug', 'arabic': 'أوغندا'},
    'Ukraine': {'code': 'ua', 'arabic': 'أوكرانيا'},
    'United Arab Emirates': {'code': 'ae', 'arabic': 'الإمارات العربية المتحدة'},
    'United Kingdom': {'code': 'gb', 'arabic': 'المملكة المتحدة'},
    'United States': {'code': 'us', 'arabic': 'الولايات المتحدة الأمريكية'},
    'Uruguay': {'code': 'uy', 'arabic': 'أوروغواي'},
    'Uzbekistan': {'code': 'uz', 'arabic': 'أوزبكستان'},
    'Vanuatu': {'code': 'vu', 'arabic': 'فانواتو'},
    'Vatican City': {'code': 'va', 'arabic': 'الفاتيكان'},
    'Venezuela': {'code': 've', 'arabic': 'فنزويلا'},
    'Vietnam': {'code': 'vn', 'arabic': 'فيتنام'},
    'Yemen': {'code': 'ye', 'arabic': 'اليمن'},
    'Zambia': {'code': 'zm', 'arabic': 'زامبيا'},
    'Zimbabwe': {'code': 'zw', 'arabic': 'زيمبابوي'}
}

def ensure_flags_directory():
    """Make sure the flags directory exists"""
    if not os.path.exists(FLAGS_DIR):
        os.makedirs(FLAGS_DIR)

def download_flag(country_code):
    """Download a flag if it doesn't already exist locally"""
    flag_path = os.path.join(FLAGS_DIR, f"{country_code}.png")
    
    # If flag already exists, just return the local path
    if os.path.exists(flag_path):
        return f"/static/flags/{country_code}.png"
    
    # If it doesn't exist, download it
    try:
        response = requests.get(FLAG_API.format(country_code))
        if response.status_code == 200:
            with open(flag_path, 'wb') as f:
                f.write(response.content)
            print(f"Downloaded flag for {country_code}")
            return f"/static/flags/{country_code}.png"
        else:
            print(f"Failed to download flag for {country_code}: {response.status_code}")
            return FLAG_API.format(country_code)  # Fall back to API URL
    except Exception as e:
        print(f"Error downloading flag for {country_code}: {e}")
        return FLAG_API.format(country_code)  # Fall back to API URL

def download_all_flags():
    """Download all flags at once"""
    ensure_flags_directory()
    total = len(COUNTRIES)
    current = 0
    
    for country_name, country_data in COUNTRIES.items():
        country_code = country_data['code']
        current += 1
        print(f"Downloading flag {current}/{total}: {country_name} ({country_code})")
        
        download_flag(country_code)
        time.sleep(0.2)  # Small delay to avoid overloading the server

def get_flag_url(country_code):
    """Get the URL for a flag, preferring local files"""
    flag_path = os.path.join(FLAGS_DIR, f"{country_code}.png")
    if os.path.exists(flag_path):
        return f"/static/flags/{country_code}.png"
    
    # If not available locally, download it
    return download_flag(country_code)

def get_random_country():
    # Exclude countries that have been already answered
    used_countries = set(session.get('used_countries', []))
    available_countries = [c for c in COUNTRIES.keys() if c not in used_countries]
    
    # If we've used up all countries, reset but don't repeat the most recent ones
    if not available_countries or len(available_countries) < 10:
        session['used_countries'] = session.get('used_countries', [])[-5:]
        available_countries = [c for c in COUNTRIES.keys() if c not in session['used_countries']]
    
    return random.choice(available_countries)

def get_random_flags(count, exclude=None):
    exclude = exclude or []
    all_codes = [country_data['code'] for country_data in COUNTRIES.values()]
    available_codes = [c for c in all_codes if c not in exclude]
    
    # If we need more flags than available, allow reuse but not immediate duplication
    if count > len(available_codes):
        return random.sample(all_codes, count)
    
    return random.sample(available_codes, count)

@app.route('/')
def index():
    ensure_flags_directory()
    
    if 'score' not in session:
        session['score'] = 0
        session['correct_flags'] = []
        session['used_countries'] = []
        session['current_flags'] = get_random_flags(3)
    
    target_country = get_random_country()
    target_code = COUNTRIES[target_country]['code']
    
    # Download the flag if needed
    flag_url = get_flag_url(target_code)
    
    # Download all the current flags
    for code in session['current_flags']:
        get_flag_url(code)
    
    # Ensure the target flag is among the choices
    if target_code not in session['current_flags']:
        # Replace a random flag with the target flag
        session['current_flags'][random.randint(0, len(session['current_flags'])-1)] = target_code
    
    session['target'] = target_country
    session['language'] = session.get('language', 'english')
    
    # Get flag count statistics
    flags_count = len(os.listdir(FLAGS_DIR)) if os.path.exists(FLAGS_DIR) else 0
    total_countries = len(COUNTRIES)
    
    return render_template('game.html', 
                          countries=COUNTRIES,
                          target=target_country,
                          target_arabic=COUNTRIES[target_country]['arabic'],
                          correct_flags=session['correct_flags'],
                          current_flags=session['current_flags'],
                          FLAG_API=FLAG_API,
                          language=session['language'],
                          flag_url=flag_url,
                          flags_count=flags_count,
                          total_countries=total_countries)

@app.route('/check_answer', methods=['POST'])
def check_answer():
    user_choice = request.form['country']
    is_correct = request.form.get('correct', 'false') == 'true'
    target = session.get('target')
    target_code = COUNTRIES[target]['code']
    
    # Add current target to used countries to avoid repeating
    if target not in session.get('used_countries', []):
        if 'used_countries' not in session:
            session['used_countries'] = []
        session['used_countries'].append(target)
    
    if is_correct:
        session['score'] += 1
        if user_choice not in session['correct_flags']:
            session['correct_flags'].append(user_choice)
    
    # Generate new target and flags
    new_target = get_random_country()
    new_target_code = COUNTRIES[new_target]['code']
    
    # Calculate flag count based on progress
    flag_count = min(3 + session['score'] // 5, 8)  # Increase difficulty gradually up to 8 flags
    
    # Get new flags ensuring no repetition with correct flags
    # Only exclude answered flags, not just the current ones
    new_flags = get_random_flags(flag_count, exclude=session.get('correct_flags', []))
    
    # Download all new flags
    for code in new_flags:
        get_flag_url(code)
    
    # Ensure target flag is in the choices
    if new_target_code not in new_flags:
        if len(new_flags) > 0:
            new_flags[random.randint(0, len(new_flags)-1)] = new_target_code
        else:
            new_flags = [new_target_code]
    
    # Update session
    session['target'] = new_target
    session['current_flags'] = new_flags
    
    # Get flag URLs
    flag_urls = {code: get_flag_url(code) for code in new_flags}
    
    # Return JSON for AJAX update
    return jsonify({
        'target': new_target,
        'target_code': new_target_code,
        'target_arabic': COUNTRIES[new_target]['arabic'],
        'current_flags': new_flags,
        'flag_urls': flag_urls,
        'score': session['score']
    })

@app.route('/switch_language', methods=['POST'])
def switch_language():
    language = request.form.get('language', 'english')
    session['language'] = language
    return jsonify({'success': True})

@app.route('/reset_game', methods=['POST'])
def reset_game():
    # Clear all game-related session data
    session['score'] = 0
    session['correct_flags'] = []
    session['used_countries'] = []
    session['current_flags'] = get_random_flags(3)
    
    # Get a new target country
    target_country = get_random_country()
    target_code = COUNTRIES[target_country]['code']
    
    # Ensure the target flag is among the choices
    if target_code not in session['current_flags']:
        session['current_flags'][random.randint(0, len(session['current_flags'])-1)] = target_code
    
    session['target'] = target_country
    
    # Get flag URLs
    flag_urls = {code: get_flag_url(code) for code in session['current_flags']}
    
    # Return JSON for AJAX update
    return jsonify({
        'target': target_country,
        'target_code': target_code,
        'target_arabic': COUNTRIES[target_country]['arabic'],
        'current_flags': session['current_flags'],
        'flag_urls': flag_urls,
        'score': 0
    })

@app.route('/download_flags', methods=['GET'])
def download_flags_route():
    download_all_flags()
    flags_count = len(os.listdir(FLAGS_DIR)) if os.path.exists(FLAGS_DIR) else 0
    return jsonify({
        'success': True, 
        'message': 'All flags downloaded',
        'count': flags_count,
        'total': len(COUNTRIES)
    })

@app.route('/flags_status', methods=['GET'])
def flags_status():
    flags_count = len(os.listdir(FLAGS_DIR)) if os.path.exists(FLAGS_DIR) else 0
    return jsonify({
        'count': flags_count,
        'total': len(COUNTRIES)
    })

if __name__ == '__main__':
    ensure_flags_directory()
    app.run(debug=True)